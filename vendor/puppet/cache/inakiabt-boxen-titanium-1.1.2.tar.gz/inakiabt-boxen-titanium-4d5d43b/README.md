# Titanium Puppet Module for Boxen

## Usage

```puppet
include titanium
```

## Required Puppet Modules

* `node`
